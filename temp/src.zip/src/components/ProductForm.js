import React, { useEffect } from 'react';
import { Form, Input, Button, Modal } from 'antd';
import { useDispatch } from 'react-redux';
import { createProduct, updateProduct } from '../slices/productSlice';

const ProductForm = ({ open, onClose, product }) => {
  const [form] = Form.useForm();
  const dispatch = useDispatch();

  useEffect(() => {
    if (product) {
      form.setFieldsValue({
        productName: product.productName,
        productDescription: product.productDescription,
        state: product.state,
      });
    } else {
      form.resetFields();
    }
  }, [product, form]);

  const onFinish = (values) => {
    if (product) {
      dispatch(updateProduct({ id: product.productID, data: values }));
    } else {
      dispatch(createProduct(values));
    }
    form.resetFields();
    onClose();
  };

  return (
    <Modal
      title={product ? 'Edit Product' : 'Add Product'}
      open={open}
      onCancel={onClose}
      footer={null}
    >
      <Form form={form} onFinish={onFinish} layout="vertical">
        <Form.Item
          name="productName"
          label="Product Name"
          rules={[{ required: true, message: 'Please enter product name' }]}
        >
          <Input placeholder="Enter product name" />
        </Form.Item>
        <Form.Item
          name="productDescription"
          label="Product Description"
          rules={[{ required: true, message: 'Please enter product description' }]}
        >
          <Input.TextArea placeholder="Enter product description" />
        </Form.Item>
        <Form.Item
          name="state"
          label="State"
          rules={[{ required: true, message: 'Please enter state' }]}
        >
          <Input placeholder="Enter state (e.g., Active)" />
        </Form.Item>
        <Form.Item>
          <div className="flex justify-end gap-2">
            <Button onClick={onClose}>Cancel</Button>
            <Button type="primary" htmlType="submit">
              {product ? 'Update' : 'Create'}
            </Button>
          </div>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default ProductForm;
// // import React, { useEffect, useState } from "react";
// // import { useDispatch, useSelector } from "react-redux";
// // import { Form, Select, Modal, InputNumber, Button, Alert, message } from "antd";
// // import { getCompanies } from "../slices/companySlice";
// // import { getProducts } from "../slices/productSlice";
// // import { getFeeStructuresByFeeType } from "../slices/feeSlice";
// // import {
// //   createSubscription,
// //   updateSubscription,
// // } from "../slices/companyProductSubscriptionSlice";

// // const { Option } = Select;

// // const NO_OF_USERS_OR_DEVICES = [
// //   { value: 1, label: "0-10" },
// //   { value: 2, label: "11-50" },
// //   { value: 3, label: "51-100" },
// //   { value: 4, label: "Unlimited" },
// // ];

// // const SubscriptionForm = ({ open, onClose, subscription }) => {
// //   const [form] = Form.useForm();
// //   const dispatch = useDispatch();
// //   const { companies } = useSelector((state) => state.company || {});
// //   const { products } = useSelector((state) => state.product || {});
// //   const { feeStructures, error } = useSelector((state) => state.fee || {});
// //   const [subscriptionFee, setSubscriptionFee] = useState(null);

// //   useEffect(() => {
// //     dispatch(getCompanies());
// //     dispatch(getProducts());

// //     // Set default feeType and fetch fee structures
// //     const feeType = subscription ? subscription.feeType : 2; // Default to 2 (Subscription)
// //     if (feeType !== undefined && feeType !== null) {
// //       dispatch(getFeeStructuresByFeeType(feeType));
// //     }

// //     if (subscription) {
// //       form.setFieldsValue({
// //         companyID: subscription.companyID,
// //         productID: subscription.productID,
// //         notifyBeforeXDays: subscription.notifyBeforeXDays,
// //         noOfUsers: subscription.noOfUsers,
// //         noOfDevices: subscription.noOfDevices,
// //         feeType: subscription.feeType || 2, // Default to Subscription
// //       });
// //     } else {
// //       form.setFieldsValue({
// //         feeType: 2, // Auto-set to Subscription
// //       });
// //     }
// //   }, [subscription, form, dispatch]);

// //   // Update subscription fee when feeType changes
// //   useEffect(() => {
// //     const feeType = form.getFieldValue("feeType");

// //     if (feeType !== undefined && feeStructures.length > 0) {
// //       const fee =
// //         feeStructures.find((f) => f.feeType === feeType)?.feeAmount || 0;
// //       setSubscriptionFee(fee);
// //       message.info(`You will pay ${fee} amount`);
// //     }
// //   }, [form.getFieldValue("feeType"), feeStructures]);

// //   const handleSubmit = async (values) => {
// //     try {
// //       const subscriptionData = {
// //         companyID: values.companyID,
// //         productID: values.productID,
// //         notifyBeforeXDays: values.notifyBeforeXDays,
// //         noOfUsers: values.noOfUsers,
// //         noOfDevices: values.noOfDevices,
// //         feeType: values.feeType,
// //       };

// //       if (subscription) {
// //         // Update existing subscription
// //         await dispatch(
// //           updateSubscription({
// //             id: subscription.companyProductID,
// //             data: subscriptionData,
// //           })
// //         ).unwrap();
// //       } else {
// //         // Create new subscription
// //         await dispatch(createSubscription(subscriptionData)).unwrap();
// //       }

// //       form.resetFields();
// //       setSubscriptionFee(null);
// //       onClose();
// //     } catch (error) {
// //       // Error is handled by the slice (toast.error is shown)
// //       console.error("Submission error:", error);
// //     }
// //   };

// //   return (
// //     <Modal
// //       open={open}
// //       centered
// //       footer={null}
// //       destroyOnHidden // Replaced deprecated destroyOnClose
// //       onCancel={() => {
// //         form.resetFields();
// //         setSubscriptionFee(null);
// //         onClose();
// //       }}
// //       title={
// //         <span className="flex items-center gap-2">
// //           {subscription ? "Edit.Linked subscription" : "Add Subscription"}
// //         </span>
// //       }
// //       className="rounded-xl"
// //     >
// //       {error && (
// //         <Alert
// //           type="error"
// //           message={`Error: ${error}`}
// //           showIcon
// //           style={{ marginBottom: "1rem" }}
// //         />
// //       )}

// //       <Form
// //         form={form}
// //         layout="vertical"
// //         onFinish={handleSubmit}
// //         className="space-y-3"
// //       >
// //         <Form.Item
// //           name="companyID"
// //           label="Company"
// //           rules={[{ required: true, message: "Please select a company" }]}
// //         >
// //           <Select placeholder="Select a company" className="rounded-md">
// //             {companies?.map((company) => (
// //               <Option key={company.companyID} value={company.companyID}>
// //                 {company.companyName}
// //               </Option>
// //             ))}
// //           </Select>
// //         </Form.Item>

// //         <Form.Item
// //           name="productID"
// //           label="Product"
// //           rules={[{ required: true, message: "Please select a product" }]}
// //         >
// //           <Select placeholder="Select a product" className="rounded-md">
// //             {products?.map((product) => (
// //               <Option key={product.productID} value={product.productID}>
// //                 {product.productName}
// //               </Option>
// //             ))}
// //           </Select>
// //         </Form.Item>

// //         <Form.Item
// //           name="noOfUsers"
// //           label="Number of Users"
// //           rules={[{ required: true, message: "Please select number of users" }]}
// //         >
// //           <Select placeholder="Select number of users" className="rounded-md">
// //             {NO_OF_USERS_OR_DEVICES.map((option) => (
// //               <Option key={option.value} value={option.value}>
// //                 {option.label}
// //               </Option>
// //             ))}
// //           </Select>
// //         </Form.Item>

// //         <Form.Item
// //           name="noOfDevices"
// //           label="Number of Devices"
// //           rules={[
// //             { required: true, message: "Please select number of devices" },
// //           ]}
// //         >
// //           <Select placeholder="Select number of devices" className="rounded-md">
// //             {NO_OF_USERS_OR_DEVICES.map((option) => (
// //               <Option key={option.value} value={option.value}>
// //                 {option.label}
// //               </Option>
// //             ))}
// //           </Select>
// //         </Form.Item>

// //         <Form.Item
// //           name="feeType"
// //           label="Fee Type"
// //           rules={[{ required: true, message: "Please select fee type" }]}
// //         >
// //           <Select
// //             placeholder="Select fee type"
// //             className="rounded-md"
// //             disabled={
// //               !form.getFieldValue("noOfUsers") ||
// //               !form.getFieldValue("noOfDevices") ||
// //               feeStructures.length === 0
// //             }
// //           >
// //             {feeStructures?.map((fee) => (
// //               <Option key={fee.feeType} value={fee.feeType}>
// //                 {fee.feeTypeName || `Type ${fee.feeType}`}
// //               </Option>
// //             ))}
// //           </Select>
// //         </Form.Item>

// //         <Form.Item
// //           name="notifyBeforeXDays"
// //           label="Notify Before (Days)"
// //           rules={[
// //             { required: true, message: "Please enter notification days" },
// //           ]}
// //         >
// //           <InputNumber
// //             min={0}
// //             placeholder="e.g., 10"
// //             className="w-full rounded-md"
// //           />
// //         </Form.Item>

// //         {subscriptionFee !== null && (
// //           <Alert
// //             type="info"
// //             message={`Subscription Fee: $${subscriptionFee}`}
// //             showIcon
// //             style={{ marginBottom: "1rem" }}
// //           />
// //         )}

// //         <Form.Item>
// //           <div className="flex justify-end gap-3 mt-2">
// //             <Button
// //               onClick={() => {
// //                 form.resetFields();
// //                 setSubscriptionFee(null);
// //                 onClose();
// //               }}
// //             >
// //               Cancel
// //             </Button>
// //             <Button
// //               type="primary"
// //               htmlType="submit"
// //               className="bg-blue-600 hover:bg-blue-700 text-white"
// //             >
// //               {subscription ? "Update" : "Create"}
// //             </Button>
// //           </div>
// //         </Form.Item>
// //       </Form>
// //     </Modal>
// //   );
// // };

// // export default SubscriptionForm;

// import React, { useEffect, useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { Form, Select, Modal, InputNumber, Button, Alert, message } from "antd";
// import { getCompanies } from "../slices/companySlice";
// import { getProducts } from "../slices/productSlice";
// import { getFeeStructuresByFeeType } from "../slices/feeSlice";
// import {
//   createSubscription,
//   updateSubscription,
// } from "../slices/companyProductSubscriptionSlice";

// const { Option } = Select;

// const NO_OF_USERS_OR_DEVICES = [
//   { value: 1, label: "0-10" },
//   { value: 2, label: "11-50" },
//   { value: 3, label: "51-100" },
//   { value: 4, label: "Unlimited" },
// ];

// const SubscriptionForm = ({ open, onClose, subscription }) => {
//   const [form] = Form.useForm();
//   const dispatch = useDispatch();
//   const { companies } = useSelector((state) => state.company || {});
//   const { products } = useSelector((state) => state.product || {});
//   const { feeStructures, error } = useSelector((state) => state.fee || {});
//   const [subscriptionFee, setSubscriptionFee] = useState(null);

//   useEffect(() => {
//     dispatch(getCompanies());
//     dispatch(getProducts());

//     // Set default feeType and fetch initial fee structures
//     const initialFeeType = subscription ? subscription.feeType : 2; // Default to 2 (Subscription)
//     if (initialFeeType !== undefined && initialFeeType !== null) {
//       dispatch(getFeeStructuresByFeeType(initialFeeType));
//     }

//     if (subscription) {
//       form.setFieldsValue({
//         companyID: subscription.companyID,
//         productID: subscription.productID,
//         notifyBeforeXDays: subscription.notifyBeforeXDays,
//         noOfUsers: subscription.noOfUsers,
//         noOfDevices: subscription.noOfDevices,
//         feeType: subscription.feeType || 2, // Default to Subscription
//       });
//     } else {
//       form.setFieldsValue({
//         feeType: 2, // Auto-set to Subscription
//       });
//     }
//   }, [subscription, form, dispatch]);

//   // Fetch fee structures when feeType changes in the form
//   useEffect(() => {
//     const feeType = form.getFieldValue("feeType");
//     if (feeType !== undefined && feeType !== null) {
//       dispatch(getFeeStructuresByFeeType(feeType));
//     }
//   }, [form.getFieldValue("feeType"), dispatch]);

//   // Update subscription fee when feeStructures or feeType changes
//   useEffect(() => {
//     const feeType = form.getFieldValue("feeType");
//     console.log("feeStructures updated:", feeStructures); // Debug log
//     if (feeType !== undefined && feeStructures.length > 0) {
//       const fee =
//         feeStructures.find((f) => f.feeType === feeType)?.feeAmount || 0;
//       setSubscriptionFee(fee);
//       message.info(`You will pay ${fee} amount`);
//     } else {
//       setSubscriptionFee(null); // Reset fee if no data or no match
//     }
//   }, [feeStructures, form.getFieldValue("feeType")]);

//   const handleSubmit = async (values) => {
//     try {
//       const subscriptionData = {
//         companyID: values.companyID,
//         productID: values.productID,
//         notifyBeforeXDays: values.notifyBeforeXDays,
//         noOfUsers: values.noOfUsers,
//         noOfDevices: values.noOfDevices,
//         feeType: values.feeType,
//       };

//       if (subscription) {
//         // Update existing subscription
//         await dispatch(
//           updateSubscription({
//             id: subscription.companyProductID,
//             data: subscriptionData,
//           })
//         ).unwrap();
//       } else {
//         // Create new subscription
//         await dispatch(createSubscription(subscriptionData)).unwrap();
//       }

//       form.resetFields();
//       setSubscriptionFee(null);
//       onClose();
//     } catch (error) {
//       // Error is handled by the slice (toast.error is shown)
//       console.error("Submission error:", error);
//     }
//   };

//   return (
//     <Modal
//       open={open}
//       centered
//       footer={null}
//       destroyOnHidden // Replaced deprecated destroyOnClose
//       onCancel={() => {
//         form.resetFields();
//         setSubscriptionFee(null);
//         onClose();
//       }}
//       title={
//         <span className="flex items-center gap-2">
//           {subscription ? "Edit Subscription" : "Add Subscription"}
//         </span>
//       }
//       className="rounded-xl"
//     >
//       {error && (
//         <Alert
//           type="error"
//           message={`Error: ${error}`}
//           showIcon
//           style={{ marginBottom: "1rem" }}
//         />
//       )}

//       <Form
//         form={form}
//         layout="vertical"
//         onFinish={handleSubmit}
//         className="space-y-3"
//       >
//         <Form.Item
//           name="companyID"
//           label="Company"
//           rules={[{ required: true, message: "Please select a company" }]}
//         >
//           <Select placeholder="Select a company" className="rounded-md">
//             {companies?.map((company) => (
//               <Option key={company.companyID} value={company.companyID}>
//                 {company.companyName}
//               </Option>
//             ))}
//           </Select>
//         </Form.Item>

//         <Form.Item
//           name="productID"
//           label="Product"
//           rules={[{ required: true, message: "Please select a product" }]}
//         >
//           <Select placeholder="Select a product" className="rounded-md">
//             {products?.map((product) => (
//               <Option key={product.productID} value={product.productID}>
//                 {product.productName}
//               </Option>
//             ))}
//           </Select>
//         </Form.Item>

//         <Form.Item
//           name="noOfUsers"
//           label="Number of Users"
//           rules={[{ required: true, message: "Please select number of users" }]}
//         >
//           <Select placeholder="Select number of users" className="rounded-md">
//             {NO_OF_USERS_OR_DEVICES.map((option) => (
//               <Option key={option.value} value={option.value}>
//                 {option.label}
//               </Option>
//             ))}
//           </Select>
//         </Form.Item>

//         <Form.Item
//           name="noOfDevices"
//           label="Number of Devices"
//           rules={[
//             { required: true, message: "Please select number of devices" },
//           ]}
//         >
//           <Select placeholder="Select number of devices" className="rounded-md">
//             {NO_OF_USERS_OR_DEVICES.map((option) => (
//               <Option key={option.value} value={option.value}>
//                 {option.label}
//               </Option>
//             ))}
//           </Select>
//         </Form.Item>

//         <Form.Item
//           name="feeType"
//           label="Fee Type"
//           rules={[{ required: true, message: "Please select fee type" }]}
//         >
//           <Select
//             placeholder="Select fee type"
//             className="rounded-md"
//             disabled={
//               !form.getFieldValue("noOfUsers") ||
//               !form.getFieldValue("noOfDevices")
//             }
//           >
//             {feeStructures?.map((fee) => (
//               <Option key={fee.feeType} value={fee.feeType}>
//                 {fee.feeTypeName || `Type ${fee.feeType}`}
//               </Option>
//             ))}
//           </Select>
//         </Form.Item>

//         <Form.Item
//           name="notifyBeforeXDays"
//           label="Notify Before (Days)"
//           rules={[
//             { required: true, message: "Please enter notification days" },
//           ]}
//         >
//           <InputNumber
//             min={0}
//             placeholder="e.g., 10"
//             className="w-full rounded-md"
//           />
//         </Form.Item>

//         {subscriptionFee !== null && (
//           <Alert
//             type="info"
//             message={`Subscription Fee: $${subscriptionFee}`}
//             showIcon
//             style={{ marginBottom: "1rem" }}
//           />
//         )}

//         <Form.Item>
//           <div className="flex justify-end gap-3 mt-2">
//             <Button
//               onClick={() => {
//                 form.resetFields();
//                 setSubscriptionFee(null);
//                 onClose();
//               }}
//             >
//               Cancel
//             </Button>
//             <Button
//               type="primary"
//               htmlType="submit"
//               className="bg-blue-600 hover:bg-blue-700 text-white"
//             >
//               {subscription ? "Update" : "Create"}
//             </Button>
//           </div>
//         </Form.Item>
//       </Form>
//     </Modal>
//   );
// };

// export default SubscriptionForm;

import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Form, Select, Modal, InputNumber, Button, Alert, message } from "antd";
import { getCompanies } from "../slices/companySlice";
import { getProducts } from "../slices/productSlice";
import { getFeeStructuresByFeeType } from "../slices/feeSlice";
import {
  createSubscription,
  updateSubscription,
} from "../slices/companyProductSubscriptionSlice";

const { Option } = Select;

const NO_OF_USERS_OR_DEVICES = [
  { value: 1, label: "0-10" },
  { value: 2, label: "11-50" },
  { value: 3, label: "51-100" },
  { value: 4, label: "Unlimited" },
];

const SubscriptionForm = ({ open, onClose, subscription }) => {
  const [form] = Form.useForm();
  const dispatch = useDispatch();
  const { companies } = useSelector((state) => state.company || {});
  const { products } = useSelector((state) => state.product || {});
  const { feeStructures, error } = useSelector((state) => state.fee || {});
  const [subscriptionFee, setSubscriptionFee] = useState(null);

  useEffect(() => {
    dispatch(getCompanies());
    dispatch(getProducts());

    // Set default feeType and fetch initial fee structures
    const initialFeeType = subscription ? subscription.feeType : 2; // Default to 2 (Subscription)
    if (initialFeeType !== undefined && initialFeeType !== null) {
      dispatch(getFeeStructuresByFeeType(initialFeeType));
    }

    if (subscription) {
      form.setFieldsValue({
        companyID: subscription.companyID,
        productID: subscription.productID,
        notifyBeforeXDays: subscription.notifyBeforeXDays,
        noOfUsers: subscription.noOfUsers,
        noOfDevices: subscription.noOfDevices,
        feeType: subscription.feeType || 2, // Default to Subscription
      });
    } else {
      form.setFieldsValue({
        feeType: 2, // Auto-set to Subscription
      });
    }
  }, [subscription, form, dispatch]);

  // Fetch fee structures when feeType changes in the form
  useEffect(() => {
    const feeType = form.getFieldValue("feeType");
    if (feeType !== undefined && feeType !== null) {
      dispatch(getFeeStructuresByFeeType(feeType));
    }
  }, [form.getFieldValue("feeType"), dispatch]);

  // Update subscription fee when feeStructures or feeType changes
  useEffect(() => {
    const feeType = form.getFieldValue("feeType");
    console.log("feeStructures updated:", feeStructures); // Debug log
    if (feeType !== undefined && feeStructures.length > 0) {
      const fees = feeStructures.filter((f) => f.feeType === feeType);
      const fee = fees.length > 0 ? fees[0].feeAmount : 0; // Use first matching feeAmount
      console.log("Selected fee:", fee); // Debug log for selected fee
      setSubscriptionFee(fee);
      message.info(`You will pay ${fee} amount`);
    } else {
      setSubscriptionFee(null); // Reset fee if no data or no match
    }
  }, [feeStructures, form.getFieldValue("feeType")]);

  const handleSubmit = async (values) => {
    try {
      const subscriptionData = {
        companyID: values.companyID,
        productID: values.productID,
        notifyBeforeXDays: values.notifyBeforeXDays,
        noOfUsers: values.noOfUsers,
        noOfDevices: values.noOfDevices,
        feeType: values.feeType,
      };

      if (subscription) {
        // Update existing subscription
        await dispatch(
          updateSubscription({
            id: subscription.companyProductID,
            data: subscriptionData,
          })
        ).unwrap();
      } else {
        // Create new subscription
        await dispatch(createSubscription(subscriptionData)).unwrap();
      }

      form.resetFields();
      setSubscriptionFee(null);
      onClose();
    } catch (error) {
      // Error is handled by the slice (toast.error is shown)
      console.error("Submission error:", error);
    }
  };

  return (
    <Modal
      open={open}
      centered
      footer={null}
      destroyOnHidden // Replaced deprecated destroyOnClose
      onCancel={() => {
        form.resetFields();
        setSubscriptionFee(null);
        onClose();
      }}
      title={
        <span className="flex items-center gap-2">
          {subscription ? "Edit Subscription" : "Add Subscription"}
        </span>
      }
      className="rounded-xl"
    >
      {error && (
        <Alert
          type="error"
          message={`Error: ${error}`}
          showIcon
          style={{ marginBottom: "1rem" }}
        />
      )}

      <Form
        form={form}
        layout="vertical"
        onFinish={handleSubmit}
        className="space-y-3"
      >
        <Form.Item
          name="companyID"
          label="Company"
          rules={[{ required: true, message: "Please select a company" }]}
        >
          <Select placeholder="Select a company" className="rounded-md">
            {companies?.map((company) => (
              <Option key={company.companyID} value={company.companyID}>
                {company.companyName}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          name="productID"
          label="Product"
          rules={[{ required: true, message: "Please select a product" }]}
        >
          <Select placeholder="Select a product" className="rounded-md">
            {products?.map((product) => (
              <Option key={product.productID} value={product.productID}>
                {product.productName}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          name="noOfUsers"
          label="Number of Users"
          rules={[{ required: true, message: "Please select number of users" }]}
        >
          <Select placeholder="Select number of users" className="rounded-md">
            {NO_OF_USERS_OR_DEVICES.map((option) => (
              <Option key={option.value} value={option.value}>
                {option.label}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          name="noOfDevices"
          label="Number of Devices"
          rules={[
            { required: true, message: "Please select number of devices" },
          ]}
        >
          <Select placeholder="Select number of devices" className="rounded-md">
            {NO_OF_USERS_OR_DEVICES.map((option) => (
              <Option key={option.value} value={option.value}>
                {option.label}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          name="feeType"
          label="Fee Type"
          rules={[{ required: true, message: "Please select fee type" }]}
        >
          <Select
            placeholder="Select fee type"
            className="rounded-md"
            disabled={
              !form.getFieldValue("noOfUsers") ||
              !form.getFieldValue("noOfDevices")
            }
          >
            {feeStructures?.map((fee) => (
              <Option key={fee.feeType} value={fee.feeType}>
                {fee.feeTypeName || `Type ${fee.feeType}`}
              </Option>
            ))}
          </Select>
        </Form.Item>

        <Form.Item
          name="notifyBeforeXDays"
          label="Notify Before (Days)"
          rules={[
            { required: true, message: "Please enter notification days" },
          ]}
        >
          <InputNumber
            min={0}
            placeholder="e.g., 10"
            className="w-full rounded-md"
          />
        </Form.Item>

        {subscriptionFee !== null && (
          <Alert
            type="info"
            message={`Subscription Fee: $${subscriptionFee}`}
            showIcon
            style={{ marginBottom: "1rem" }}
          />
        )}

        <Form.Item>
          <div className="flex justify-end gap-3 mt-2">
            <Button
              onClick={() => {
                form.resetFields();
                setSubscriptionFee(null);
                onClose();
              }}
            >
              Cancel
            </Button>
            <Button
              type="primary"
              htmlType="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {subscription ? "Update" : "Create"}
            </Button>
          </div>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default SubscriptionForm;

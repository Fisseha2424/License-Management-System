// // import React, { useEffect, useState } from 'react';
// // import { useDispatch, useSelector } from 'react-redux';
// // import { getProducts, deleteProduct } from '../slices/productSlice';
// // import ProductForm from '../components/ProductForm';
// // import { Table, Button, Space } from 'antd';

// // const ProductPage = () => {
// //   const dispatch = useDispatch();
// //   const { products, status } = useSelector((state) => state.product);
// //   const [isFormOpen, setIsFormOpen] = useState(false);
// //   const [selectedProduct, setSelectedProduct] = useState(null);

// //   useEffect(() => {
// //     dispatch(getProducts());
// //   }, [dispatch]);

// //   const columns = [
// //     { title: 'Product Name', dataIndex: 'productName', key: 'productName' },
// //     { title: 'Description', dataIndex: 'productDescription', key: 'productDescription' },
// //     { title: 'State', dataIndex: 'state', key: 'state' },
// //     {
// //       title: 'Actions',
// //       key: 'actions',
// //       render: (_, record) => (
// //         <Space>
// //           <Button onClick={() => { setSelectedProduct(record); setIsFormOpen(true); }}>Edit</Button>
// //           <Button danger onClick={() => dispatch(deleteProduct(record.productID))}>Delete</Button>
// //         </Space>
// //       ),
// //     },
// //   ];

// //   return (
// //     <div style={{ padding: '20px' }}>
// //       <h1>Products</h1>
// //       {status === 'loading' ? <p>Loading...</p> : (
// //         <>
// //           <Button type="primary" onClick={() => { setSelectedProduct(null); setIsFormOpen(true); }} style={{ marginBottom: '20px' }}>
// //             Add Product
// //           </Button>
// //           <Table dataSource={products} columns={columns} rowKey="productID" />
// //           <ProductForm open={isFormOpen} onClose={() => setIsFormOpen(false)} product={selectedProduct} />
// //         </>
// //       )}
// //     </div>
// //   );
// // };

// // export default ProductPage;

// import React, { useEffect, useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { getProducts, deleteProduct } from "../slices/productSlice";
// import ProductForm from "../components/ProductForm";
// import { Table, Button, Alert } from "antd";

// const ProductPage = () => {
//   const dispatch = useDispatch();
//   const {
//     products = [],
//     status = "idle",
//     error = null,
//   } = useSelector((state) => state.product || {});
//   const [isFormOpen, setIsFormOpen] = useState(false);
//   const [selectedProduct, setSelectedProduct] = useState(null);

//   useEffect(() => {
//     dispatch(getProducts());
//   }, [dispatch]);

//   const handleAdd = () => {
//     setSelectedProduct(null);
//     setIsFormOpen(true);
//   };

//   const handleEdit = (record) => {
//     setSelectedProduct(record);
//     setIsFormOpen(true);
//   };

//   const handleDelete = (record) => {
//     dispatch(deleteProduct(record.productID));
//   };

//   const columns = [
//     { title: "Product Name", dataIndex: "productName", key: "productName" },
//     {
//       title: "Description",
//       dataIndex: "productDescription",
//       key: "productDescription",
//     },
//     { title: "State", dataIndex: "state", key: "state" },
//     {
//       title: "Actions",
//       key: "actions",
//       render: (_, record) => (
//         <div className="flex space-x-2">
//           <Button onClick={() => handleEdit(record)}>Edit</Button>
//           <Button danger onClick={() => handleDelete(record)}>
//             Delete
//           </Button>
//         </div>
//       ),
//     },
//   ];

//   return (
//     <div className="container p-6">
//       <h1 className="text-2xl font-bold mb-4">Manage Products</h1>
//       {status === "loading" ? (
//         <p>Loading...</p>
//       ) : (
//         <>
//           {error && (
//             <Alert
//               message={`Error: ${error}`}
//               type="error"
//               style={{ marginBottom: "20px" }}
//             />
//           )}
//           <Button
//             type="primary"
//             onClick={handleAdd}
//             style={{ marginBottom: "20px" }}
//           >
//             Add Product
//           </Button>
//           <Table
//             columns={columns}
//             dataSource={products}
//             rowKey="productID"
//             loading={status === "loading"}
//           />
//           <ProductForm
//             open={isFormOpen}
//             onClose={() => setIsFormOpen(false)}
//             product={selectedProduct}
//           />
//         </>
//       )}
//     </div>
//   );
// };

// export default ProductPage;

import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getProducts, deleteProduct } from '../slices/productSlice';
import ProductForm from '../components/ProductForm';
import { Table, Button, Alert } from 'antd';

const ProductPage = () => {
  const dispatch = useDispatch();
  const { products = [], status = 'idle', error = null } = useSelector((state) => state.product || {});
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);

  useEffect(() => {
    dispatch(getProducts());
  }, [dispatch]);

  const handleAdd = () => {
    setSelectedProduct(null);
    setIsFormOpen(true);
  };

  const handleEdit = (record) => {
    setSelectedProduct(record);
    setIsFormOpen(true);
  };

  const handleDelete = (record) => {
    dispatch(deleteProduct(record.productID));
  };

  const columns = [
    { title: 'Product Name', dataIndex: 'productName', key: 'productName' },
    { title: 'Description', dataIndex: 'productDescription', key: 'productDescription' },
    { title: 'State', dataIndex: 'state', key: 'state' },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <div className="flex space-x-2">
          <Button onClick={() => handleEdit(record)}>Edit</Button>
          <Button danger onClick={() => handleDelete(record)}>Delete</Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Manage Products</h1>
      {status === 'loading' ? (
        <p>Loading...</p>
      ) : (
        <>
          {error && <Alert message={`Error: ${error}`} type="error" style={{ marginBottom: '20px' }} />}
          <Button type="primary" onClick={handleAdd} style={{ marginBottom: '20px' }}>
            Add Product
          </Button>
          <Table
            columns={columns}
            dataSource={products}
            rowKey="productID"
            loading={status === 'loading'}
          />
          <ProductForm open={isFormOpen} onClose={() => setIsFormOpen(false)} product={selectedProduct} />
        </>
      )}
    </div>
  );
};

export default ProductPage;

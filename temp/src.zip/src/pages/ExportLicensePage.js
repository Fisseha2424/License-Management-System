import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { exportLicense } from "../slices/licenseSlice";
import { getLicenses } from "../slices/licenseSlice";
import { Select, Button, Alert } from "antd";

const ExportLicensePage = () => {
  const dispatch = useDispatch();
  const { licenses, status, error, exportData } = useSelector(
    (state) => state.license || {}
  );
  const [selectedLicense, setSelectedLicense] = useState(null);

  useEffect(() => {
    dispatch(getLicenses());
  }, [dispatch]);

  const handleExport = () => {
    if (selectedLicense) {
      dispatch(exportLicense(selectedLicense)).then((action) => {
        if (action.payload) {
          const jsonData = JSON.stringify(action.payload, null, 2);
          const blob = new Blob([jsonData], { type: "application/json" });
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = `license_${selectedLicense}.json`;
          a.click();
          window.URL.revokeObjectURL(url);
        }
      });
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Export License</h1>
      {status === "loading" ? (
        <p>Loading...</p>
      ) : (
        <>
          {error && (
            <Alert
              message={`Error: ${error}`}
              type="error"
              style={{ marginBottom: "20px" }}
            />
          )}
          <Select
            style={{ width: "300px", marginBottom: "20px" }}
            placeholder="Select a license to export"
            onChange={(value) => setSelectedLicense(value)}
            value={selectedLicense}
          >
            {licenses.map((license) => (
              <Select.Option
                key={license.companyProductID}
                value={license.companyProductID}
              >
                {license.companyProductID}
              </Select.Option>
            ))}
          </Select>
          <Button
            type="primary"
            onClick={handleExport}
            disabled={!selectedLicense}
          >
            Export License
          </Button>
          {exportData && (
            <Alert
              message="Export successful!"
              type="success"
              style={{ marginTop: "20px" }}
            />
          )}
        </>
      )}
    </div>
  );
};

export default ExportLicensePage;

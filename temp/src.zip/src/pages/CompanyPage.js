// import React, { useEffect, useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { getCompanies, deleteCompany } from "../slices/companySlice";
// import CompanyForm from "../components/CompanyForm";
// import { Table, Button, Space } from "antd";

// const CompanyPage = () => {
//   const dispatch = useDispatch();
//   const { companies, status } = useSelector((state) => state.company);
//   const [isFormOpen, setIsFormOpen] = useState(false);
//   const [selectedCompany, setSelectedCompany] = useState(null);

//   useEffect(() => {
//     dispatch(getCompanies());
//   }, [dispatch]);

//   const handleAdd = () => {
//     setSelectedCompany(null);
//     setIsFormOpen(true);
//   };

//   const handleEdit = (record) => {
//     setSelectedCompany(record);
//     setIsFormOpen(true);
//   };

//   const handleDelete = (record) => {
//     dispatch(deleteCompany(record.companyID));
//   };

//   const columns = [
//     { title: "Company Name", dataIndex: "companyName", key: "companyName" },
//     { title: "TIN No", dataIndex: "TINNo", key: "TINNo" },
//     { title: "Email", dataIndex: "email", key: "email" },
//     { title: "Mobile No", dataIndex: "mobileNo", key: "mobileNo" },
//     { title: "Company Type", dataIndex: "companyType", key: "companyType" },
//     { title: "State", dataIndex: "state", key: "state" },
//     {
//       title: "Actions",
//       key: "actions",
//       render: (_, record) => (
//         <Space>
//           <Button type="primary" onClick={() => handleEdit(record)}>
//             Edit
//           </Button>
//           <Button danger onClick={() => handleDelete(record)}>
//             Delete
//           </Button>
//         </Space>
//       ),
//     },
//   ];

//   return (
//     <div className="container p-6">
//       {status === "loading" ? (
//         <p>Loading...</p>
//       ) : (
//         <>
//           <div className="flex justify-between items-center mb-4">
//             <h2 className="text-2xl font-bold">Manage Companies</h2>
//             <Button type="primary" onClick={handleAdd}>
//               Add Company
//             </Button>
//           </div>
//           <Table
//             columns={columns}
//             dataSource={Array.isArray(companies) ? companies : []}
//             rowKey="companyID"
//             loading={status === "loading"}
//           />
//           <CompanyForm
//             open={isFormOpen}
//             onClose={() => setIsFormOpen(false)}
//             company={selectedCompany}
//           />
//         </>
//       )}
//     </div>
//   );
// };

// export default CompanyPage;


import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getCompanies, deleteCompany } from '../slices/companySlice';
import CompanyForm from '../components/CompanyForm';
import { Table, Button, Alert } from 'antd';

const CompanyPage = () => {
  const dispatch = useDispatch();
  const { companies, status, error } = useSelector((state) => state.company || {});
  const [isFormOpen, setIsFormOpen] = React.useState(false);
  const [selectedCompany, setSelectedCompany] = React.useState(null);

  useEffect(() => {
    dispatch(getCompanies());
  }, [dispatch]);

  const handleAdd = () => {
    setSelectedCompany(null);
    setIsFormOpen(true);
  };

  const handleEdit = (record) => {
    setSelectedCompany(record);
    setIsFormOpen(true);
  };

  const handleDelete = (record) => {
    dispatch(deleteCompany(record.companyID));
  };

  const columns = [
    { title: 'Company Name', dataIndex: 'companyName', key: 'companyName' },
    { title: 'TIN No', dataIndex: 'tinNo', key: 'tinNo' },
    { title: 'Email', dataIndex: 'email', key: 'email' },
    { title: 'Mobile No', dataIndex: 'mobileNo', key: 'mobileNo' },
    { title: 'Company Type', dataIndex: 'companyType', key: 'companyType' },
    { title: 'State', dataIndex: 'state', key: 'state' },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <div className="flex space-x-2">
          <Button onClick={() => handleEdit(record)}>Edit</Button>
          <Button danger onClick={() => handleDelete(record)}>Delete</Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Manage Companies</h1>
      {status === 'loading' ? (
        <p>Loading...</p>
      ) : (
        <>
          {error && <Alert message={`Error: ${error}`} type="error" style={{ marginBottom: '20px' }} />}
          <Button type="primary" onClick={handleAdd} style={{ marginBottom: '20px' }}>
            Add Company
          </Button>
          <Table
            columns={columns}
            dataSource={companies}
            rowKey="companyID"
            loading={status === 'loading'}
          />
          <CompanyForm open={isFormOpen} onClose={() => setIsFormOpen(false)} company={selectedCompany} />
        </>
      )}
    </div>
  );
};

export default CompanyPage;
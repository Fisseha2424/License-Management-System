import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Form, Select, Modal, InputNumber } from "antd";
import { getCompanies } from "../slices/companySlice";
import { getProducts } from "../slices/productSlice";
import {
  createSubscription,
  updateSubscription,
} from "../slices/companyProductSubscriptionSlice";

const { Option } = Select;

const SubscriptionForm = ({ open, onClose, subscription }) => {
  const [form] = Form.useForm();
  const dispatch = useDispatch();
  const { companies } = useSelector((state) => state.company || {});
  const { products } = useSelector((state) => state.product || {});

  useEffect(() => {
    dispatch(getCompanies());
    dispatch(getProducts());
    if (subscription) {
      form.setFieldsValue({
        companyID: subscription.companyID,
        productID: subscription.productID,
        notifyBeforeXDays: subscription.notifyBeforeXDays,
      });
    } else {
      form.resetFields();
    }
  }, [subscription, form, dispatch]);

  const handleSubmit = (values) => {
    if (subscription) {
      dispatch(
        updateSubscription({
          id: subscription.companyProductID,
          data: values,
        })
      );
    } else {
      dispatch(createSubscription(values));
    }
    onClose();
  };

  return (
    <Modal
      open={open}
      title={subscription ? "Edit Subscription" : "Add Subscription"}
      okText={subscription ? "Update" : "Create"}
      onCancel={onClose}
      onOk={() => form.submit()}
    >
      <Form form={form} layout="vertical" onFinish={handleSubmit}>
        <Form.Item
          name="companyID"
          label="Company"
          rules={[{ required: true, message: "Please select a company" }]}
        >
          <Select placeholder="Select a company">
            {companies?.map((company) => (
              <Option key={company.companyID} value={company.companyID}>
                {company.companyName}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          name="productID"
          label="Product"
          rules={[{ required: true, message: "Please select a product" }]}
        >
          <Select placeholder="Select a product">
            {products?.map((product) => (
              <Option key={product.productID} value={product.productID}>
                {product.productName}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          name="notifyBeforeXDays"
          label="Notify Before (Days)"
          rules={[
            { required: true, message: "Please enter notification days" },
          ]}
        >
          <InputNumber min={0} style={{ width: "100%" }} />
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default SubscriptionForm;

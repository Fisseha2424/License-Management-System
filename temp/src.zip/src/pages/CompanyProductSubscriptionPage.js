// import React, { useEffect, useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { createSelector } from "@reduxjs/toolkit"; // Import createSelector
// import {
//   getSubscriptions,
//   deleteSubscription,
// } from "../slices/companyProductSubscriptionSlice";
// import { getCompanies } from "../slices/companySlice";
// import { getProducts } from "../slices/productSlice";
// import SubscriptionForm from "../components/SubscriptionForm";
// import { Table, Button, Space, Card, Alert } from "antd";

// const selectSubscriptionState = createSelector(
//   (state) => state.companyProductSubscription || {},
//   (subscriptionState) => ({
//     subscriptions: subscriptionState.subscriptions || [],
//     status: subscriptionState.status || "idle",
//     error: subscriptionState.error || null,
//   })
// );

// const CompanyProductSubscriptionPage = () => {
//   const dispatch = useDispatch();
//   const { subscriptions, status, error } = useSelector(selectSubscriptionState); // Use memoized selector
//   const { companies } = useSelector((state) => state.company || {});
//   const { products } = useSelector((state) => state.product || {});
//   const [isFormOpen, setIsFormOpen] = useState(false);
//   const [selectedSubscription, setSelectedSubscription] = useState(null);

//   useEffect(() => {
//     dispatch(getSubscriptions());
//     dispatch(getCompanies());
//     dispatch(getProducts());
//   }, [dispatch]);

//   const handleAdd = () => {
//     setSelectedSubscription(null);
//     setIsFormOpen(true);
//   };

//   const handleEdit = (record) => {
//     setSelectedSubscription(record);
//     setIsFormOpen(true);
//   };

//   const handleDelete = (record) => {
//     dispatch(deleteSubscription(record.companyProductID));
//   };

//   const columns = [
//     {
//       title: "Subscription ID",
//       dataIndex: "companyProductID",
//       key: "companyProductID",
//     },
//     {
//       title: "Company",
//       dataIndex: "companyID",
//       key: "companyID",
//       render: (id) =>
//         companies?.find((c) => c.companyID === id)?.companyName || "Unknown",
//     },
//     {
//       title: "Product",
//       dataIndex: "productID",
//       key: "productID",
//       render: (id) =>
//         products?.find((p) => p.productID === id)?.productName || "Unknown",
//     },
//     {
//       title: "Notify Before (Days)",
//       dataIndex: "notifyBeforeXDays",
//       key: "notifyBeforeXDays",
//     },
//     { title: "State", dataIndex: "state", key: "state" },
//     {
//       title: "Created Date",
//       dataIndex: "createdDate",
//       key: "createdDate",
//       render: (date) => new Date(date).toLocaleDateString(),
//     },
//     {
//       title: "Updated Date",
//       dataIndex: "updatedDate",
//       key: "updatedDate",
//       render: (date) => new Date(date).toLocaleDateString(),
//     },
//     {
//       title: "Actions",
//       key: "actions",
//       render: (_, record) => (
//         <Space>
//           <Button type="primary" onClick={() => handleEdit(record)}>
//             Edit
//           </Button>
//           <Button danger onClick={() => handleDelete(record)}>
//             Delete
//           </Button>
//         </Space>
//       ),
//     },
//   ];

//   return (
//     <div className="min-h-screen bg-gray-100 flex items-center justify-center">
//       <Card className="w-full max-w-4xl p-6 shadow-lg rounded-lg">
//         <h1 className="text-3xl font-bold mb-6 text-gray-800">
//           Manage Subscriptions
//         </h1>
//         {status === "loading" ? (
//           <p className="text-center">Loading...</p>
//         ) : (
//           <>
//             {error && (
//               <Alert
//                 message={`Error: ${error}`}
//                 type="error"
//                 style={{ marginBottom: "20px" }}
//                 className="mb-4"
//               />
//             )}
//             <div className="mb-6 flex justify-between items-center">
//               <Button
//                 type="primary"
//                 onClick={handleAdd}
//                 className="bg-blue-600 hover:bg-blue-700"
//               >
//                 Add Subscription
//               </Button>
//             </div>
//             <Table
//               columns={columns}
//               dataSource={Array.isArray(subscriptions) ? subscriptions : []}
//               rowKey="companyProductID"
//               loading={status === "loading"}
//               className="bg-white rounded-lg"
//             />
//             <SubscriptionForm
//               open={isFormOpen}
//               onClose={() => setIsFormOpen(false)}
//               subscription={selectedSubscription}
//             />
//           </>
//         )}
//       </Card>
//     </div>
//   );
// };

// export default CompanyProductSubscriptionPage;

import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getSubscriptions, deleteSubscription } from '../slices/companyProductSubscriptionSlice';
import { getCompanies } from '../slices/companySlice';
import { getProducts } from '../slices/productSlice';
import SubscriptionForm from '../components/SubscriptionForm';
import { Table, Button, Alert, Space } from 'antd';

const CompanyProductSubscriptionPage = () => {
  const dispatch = useDispatch();
  const { subscriptions = [], status, error } = useSelector((state) => state.subscription || {});
  const { companies = [] } = useSelector((state) => state.company || {});
  const { products = [] } = useSelector((state) => state.product || {});
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedSubscription, setSelectedSubscription] = useState(null);

  useEffect(() => {
    dispatch(getSubscriptions());
    dispatch(getCompanies());
    dispatch(getProducts());
  }, [dispatch]);

  const handleAdd = () => {
    setSelectedSubscription(null);
    setIsFormOpen(true);
  };

  const handleEdit = (record) => {
    setSelectedSubscription(record);
    setIsFormOpen(true);
  };

  const handleDelete = (record) => {
    dispatch(deleteSubscription(record.companyID));
  };

  const getCompanyName = (companyID) => {
    const company = companies.find((c) => c.companyID === companyID);
    return company ? company.companyName : 'Unknown';
  };

  const getProductName = (productID) => {
    const product = products.find((p) => p.productID === productID);
    return product ? product.productName : 'Unknown';
  };

  const columns = [
    {
      title: 'Company',
      dataIndex: 'companyID',
      key: 'companyID',
      render: (companyID) => getCompanyName(companyID),
    },
    {
      title: 'Product',
      dataIndex: 'productID',
      key: 'productID',
      render: (productID) => getProductName(productID),
    },
    { title: 'Notify Before (Days)', dataIndex: 'notifyBeforeXDays', key: 'notifyBeforeXDays' },
    { title: 'State', dataIndex: 'state', key: 'state' },
    { title: 'Created Date', dataIndex: 'createdDate', key: 'createdDate', render: (date) => new Date(date).toLocaleDateString() },
    { title: 'Updated Date', dataIndex: 'updatedDate', key: 'updatedDate', render: (date) => new Date(date).toLocaleDateString() },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <Space>
          <Button onClick={() => handleEdit(record)}>Edit</Button>
          <Button danger onClick={() => handleDelete(record)}>Delete</Button>
        </Space>
      ),
    },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Manage Subscriptions</h1>
      {status === 'loading' ? (
        <p>Loading...</p>
      ) : (
        <>
          {error && <Alert message={`Error: ${error}`} type="error" style={{ marginBottom: '20px' }} />}
          <Button type="primary" onClick={handleAdd} style={{ marginBottom: '20px' }}>
            Add Subscription
          </Button>
          <Table
            columns={columns}
            dataSource={subscriptions}
            rowKey="companyProductID"
            loading={status === 'loading'}
          />
          <SubscriptionForm open={isFormOpen} onClose={() => setIsFormOpen(false)} subscription={selectedSubscription} />
        </>
      )}
    </div>
  );
};

export default CompanyProductSubscriptionPage;

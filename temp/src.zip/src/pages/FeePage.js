// // import React, { useState, useEffect } from 'react';
// // import { useDispatch, useSelector } from 'react-redux';
// // import { getFeeStructures } from '../slices/feeSlice';
// // import FeeStructureForm from '../components/FeeStructureForm';
// // import { Button } from 'antd'; // Added import

// // const FeePage = () => {
// //   const dispatch = useDispatch();
// //   const { feeStructures} = useSelector((state) => state.fee?.feeStructures||[]);
// //    const { status } = useSelector((state) => state.fee?.status||"idle");
// //   const [isFormOpen, setIsFormOpen] = useState(false);

// //   useEffect(() => {
// //     dispatch(getFeeStructures());
// //   }, [dispatch]);

// //   return (
// //     <div>
// //       <h1>Fees</h1>
// //       {status === 'loading' ? <p>Loading...</p> : <div>{/* Add fee structure list if needed */}</div>}
// //       <Button type="primary" onClick={() => setIsFormOpen(true)} style={{ marginTop: '20px' }}>
// //         Add Fee Structure
// //       </Button>
// //       <FeeStructureForm open={isFormOpen} onClose={() => setIsFormOpen(false)} />
// //     </div>
// //   );
// // };

// // export default FeePage;


// import React, { useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// // import { getFeeStructures } from '../slices/feeSlice';
// import FeeStructureForm from '../components/FeeStructureForm';
// import { Table, Button, Alert } from 'antd';

// const FeePage = () => {
//   const dispatch = useDispatch();
//   const { fees, status, error } = useSelector((state) => state.fee || {});
//   const [isFormOpen, setIsFormOpen] = React.useState(false);
//   const [selectedFee, setSelectedFee] = React.useState(null);

//   // useEffect(() => {
//   //   dispatch(getFees());
//   // }, [dispatch]);

//   const handleAdd = () => {
//     setSelectedFee(null);
//     setIsFormOpen(true);
//   };

//   const handleEdit = (record) => {
//     setSelectedFee(record);
//     setIsFormOpen(true);
//   };

//   const handleDelete = (record) => {
//     dispatch(deleteFee(record.feeID)); // Adjust ID based on your schema
//   };

//   const columns = [
//     { title: 'Fee ID', dataIndex: 'feeID', key: 'feeID' }, // Adjust fields
//     { title: 'Amount', dataIndex: 'amount', key: 'amount' },
//     { title: 'Description', dataIndex: 'description', key: 'description' },
//     { title: 'Status', dataIndex: 'status', key: 'status' },
//     {
//       title: 'Actions',
//       key: 'actions',
//       render: (_, record) => (
//         <div className="flex space-x-2">
//           <Button onClick={() => handleEdit(record)}>Edit</Button>
//           <Button danger onClick={() => handleDelete(record)}>Delete</Button>
//         </div>
//       ),
//     },
//   ];

//   return (
//     <div>
//       <h1 className="text-2xl font-bold mb-4">Manage Fees</h1>
//       {status === 'loading' ? (
//         <p>Loading...</p>
//       ) : (
//         <>
//           {error && <Alert message={`Error: ${error}`} type="error" style={{ marginBottom: '20px' }} />}
//           <Button type="primary" onClick={handleAdd} style={{ marginBottom: '20px' }}>
//             Add Fee
//           </Button>
//           <Table
//             columns={columns}
//             dataSource={fees}
//             rowKey="feeID"
//             loading={status === 'loading'}
//           />
//           <FeeForm open={isFormOpen} onClose={() => setIsFormOpen(false)} fee={selectedFee} />
//         </>
//       )}
//     </div>
//   );
// };

// export default FeePage;
import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { checkExpiry, getLicenses } from "../slices/licenseSlice";
import { Table, Alert } from "antd";

const CheckExpiryPage = () => {
  const dispatch = useDispatch();
  const { licenses, status, error } = useSelector(
    (state) => state.license || {}
  );

  useEffect(() => {
    dispatch(getLicenses());
    dispatch(checkExpiry());
  }, [dispatch]);

  const columns = [
    {
      title: "Subscription",
      dataIndex: "companyProductID",
      key: "companyProductID",
      render: (id) => id.toString(),
    },
    {
      title: "Expiry Date",
      dataIndex: "expiryDate",
      key: "expiryDate",
      render: (date) => new Date(date).toLocaleDateString(),
    },
    {
      title: "Status",
      dataIndex: "isExpired",
      key: "isExpired",
      render: (expired) => (expired ? "Expired" : "Active"),
    },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Check Expiry</h1>
      {status === "loading" ? (
        <p>Loading...</p>
      ) : (
        <>
          {error && (
            <Alert
              message={`Error: ${error}`}
              type="error"
              style={{ marginBottom: "20px" }}
            />
          )}
          <Table
            columns={columns}
            dataSource={licenses}
            rowKey="companyProductID"
            loading={status === "loading"}
          />
        </>
      )}
    </div>
  );
};

export default CheckExpiryPage;

// import React, { useEffect, useState } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import {
//   getLicenses,
//   validateLicense,
//   exportLicense,
//   checkExpiry,
//   getPublicKey,
//   importByPublicKey,
// } from "../slices/licenseSlice";
// import { getSubscriptions } from "../slices/companyProductSubscriptionSlice";
// import { getCompanies } from "../slices/companySlice";
// import { getProducts } from "../slices/productSlice";
// import LicenseForm from "../components/LicenseForm";
// import { Table, Button, Alert, Space, Card, Upload, message } from "antd";
// import { UploadOutlined } from "@ant-design/icons";

// const LicensePage = () => {
//   const dispatch = useDispatch();
//   const { licenses, status, error, exportData, publicKey } = useSelector(
//     (state) => state.license || {}
//   );
//   const { subscriptions } = useSelector(
//     (state) => state.companyProductSubscription || {}
//   );
//   const { companies } = useSelector((state) => state.company || {});
//   const { products } = useSelector((state) => state.product || {});
//   const [isFormOpen, setIsFormOpen] = useState(false);
//   const [selectedCompanyId, setSelectedCompanyId] = useState(null);

//   useEffect(() => {
//     dispatch(getLicenses());
//     dispatch(getSubscriptions());
//     dispatch(getCompanies());
//     dispatch(getProducts());
//   }, [dispatch]);

//   const getCompanyName = (companyID) => {
//     const company = companies.find((c) => c.companyID === companyID);
//     return company ? company.companyName : "Unknown";
//   };

//   const getProductName = (productID) => {
//     const product = products.find((p) => p.productID === productID);
//     return product ? product.productName : "Unknown";
//   };

//   const getSubscriptionDetails = (companyProductID) => {
//     const subscription = subscriptions.find(
//       (s) => s.companyProductID === companyProductID
//     );
//     if (subscription) {
//       setSelectedCompanyId(subscription.companyID); // Set for export
//       return `${getCompanyName(subscription.companyID)} - ${getProductName(
//         subscription.productID
//       )}`;
//     }
//     return "Unknown";
//   };

//   const columns = [
//     {
//       title: "Subscription",
//       dataIndex: "companyProductID",
//       key: "companyProductID",
//       render: (id) => getSubscriptionDetails(id),
//     },
//     {
//       title: "Expiry Date",
//       dataIndex: "expiryDate",
//       key: "expiryDate",
//       render: (date) => new Date(date).toLocaleDateString(),
//     },
//     { title: "No. of Devices", dataIndex: "noOfDevice", key: "noOfDevice" },
//     { title: "No. of Users", dataIndex: "noOfUser", key: "noOfUser" },
//     { title: "License Type", dataIndex: "licenseType", key: "licenseType" },
//     {
//       title: "License Key",
//       dataIndex: "license",
//       key: "license",
//       render: (key) => key.substring(0, 10) + "...",
//     },
//     {
//       title: "Actions",
//       key: "actions",
//       render: (_, record) => (
//         <Space>
//           <Button
//             onClick={() => dispatch(validateLicense(record.companyProductID))}
//           >
//             Validate
//           </Button>
//           <Button onClick={() => dispatch(exportLicense(selectedCompanyId))}>
//             Export
//           </Button>
//           <Button onClick={() => dispatch(checkExpiry())}>Check Expiry</Button>
//           <Button onClick={() => dispatch(getPublicKey(selectedCompanyId))}>
//             Get Public Key
//           </Button>
//         </Space>
//       ),
//     },
//   ];

//   const handleExport = (data) => {
//     if (exportData) {
//       const jsonData = JSON.stringify(exportData, null, 2);
//       const blob = new Blob([jsonData], { type: "application/json" });
//       const url = window.URL.createObjectURL(blob);
//       const a = document.createElement("a");
//       a.href = url;
//       a.download = `license_export_${selectedCompanyId}.json`;
//       a.click();
//       window.URL.revokeObjectURL(url);
//     }
//   };

//   const handleImport = (file) => {
//     const reader = new FileReader();
//     reader.onload = (e) => {
//       try {
//         const data = JSON.parse(e.target.result);
//         dispatch(importByPublicKey(data));
//       } catch (err) {
//         message.error("Invalid JSON file");
//       }
//     };
//     reader.readAsText(file);
//     return false; // Prevent upload
//   };

//   useEffect(() => {
//     if (exportData) handleExport(exportData);
//   }, [exportData, handleExport]); // Added handleExport to dependency array

//   return (
//     <div className="min-h-screen bg-gray-100 flex items-center justify-center">
//       <Card className="w-full max-w-4xl p-6 shadow-lg rounded-lg">
//         <h1 className="text-3xl font-bold mb-6 text-gray-800">
//           Manage Licenses
//         </h1>
//         {status === "loading" ? (
//           <p className="text-context">Loading...</p>
//         ) : (
//           <>
//             {error && (
//               <Alert
//                 message={`Error: ${error}`}
//                 type="error"
//                 style={{ marginBottom: "20px" }}
//                 className="mb-4"
//               />
//             )}
//             <div className="mb-6 flex justify-between items-center">
//               <Button
//                 type="primary"
//                 onClick={() => setIsFormOpen(true)}
//                 className="bg-blue-600 hover:bg-blue-700"
//               >
//                 Generate License
//               </Button>
//               <Upload
//                 beforeUpload={handleImport}
//                 showUploadList={false}
//                 accept=".json"
//               >
//                 <Button icon={<UploadOutlined />}>Import License</Button>
//               </Upload>
//             </div>
//             <Table
//               columns={columns}
//               dataSource={licenses}
//               rowKey="companyProductID"
//               loading={status === "loading"}
//               className="bg-white rounded-lg"
//             />
//             {publicKey && (
//               <Alert
//                 message={`Public Key: ${publicKey}`}
//                 type="info"
//                 style={{ marginTop: "20px" }}
//               />
//             )}
//             <LicenseForm
//               open={isFormOpen}
//               onClose={() => setIsFormOpen(false)}
//             />
//           </>
//         )}
//       </Card>
//     </div>
//   );
// };

// export default LicensePage;


import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getLicenses } from '../slices/licenseSlice';
import { getSubscriptions } from '../slices/companyProductSubscriptionSlice';
import { getCompanies } from '../slices/companySlice';
import { getProducts } from '../slices/productSlice';
import LicenseForm from '../components/LicenseForm';
import { Table, Button, Alert, Space } from 'antd';

const LicensePage = () => {
  const dispatch = useDispatch();
  const { licenses, status, error } = useSelector((state) => state.license || {});
  const { subscriptions } = useSelector((state) => state.subscription || {});
  const { companies } = useSelector((state) => state.company || {});
  const { products } = useSelector((state) => state.product || {});
  const [isFormOpen, setIsFormOpen] = useState(false);

  useEffect(() => {
    dispatch(getLicenses());
    dispatch(getSubscriptions());
    dispatch(getCompanies());
    dispatch(getProducts());
  }, [dispatch]);

  const getCompanyName = (companyID) => {
    const company = companies.find((c) => c.companyID === companyID);
    return company ? company.companyName : 'Unknown';
  };

  const getProductName = (productID) => {
    const product = products.find((p) => p.productID === productID);
    return product ? product.productName : 'Unknown';
  };

  const getSubscriptionDetails = (companyProductID) => {
    const subscription = subscriptions.find((s) => s.companyProductID === companyProductID);
    if (subscription) {
      return `${getCompanyName(subscription.companyID)} - ${getProductName(subscription.productID)}`;
    }
    return 'Unknown';
  };

  const columns = [
    { title: 'Subscription', dataIndex: 'companyProductID', key: 'companyProductID', render: (id) => getSubscriptionDetails(id) },
    { title: 'Expiry Date', dataIndex: 'expiryDate', key: 'expiryDate', render: (date) => new Date(date).toLocaleDateString() },
    { title: 'No. of Devices', dataIndex: 'noOfDevice', key: 'noOfDevice' },
    { title: 'No. of Users', dataIndex: 'noOfUser', key: 'noOfUser' },
    { title: 'License Type', dataIndex: 'licenseType', key: 'licenseType' },
    { title: 'License Key', dataIndex: 'license', key: 'license', render: (key) => key.substring(0, 10) + '...' },
    {
      title: 'Actions',
      key: 'actions',
      render: () => (
        <Space>
          <Button disabled>Edit</Button>
          <Button danger disabled>Delete</Button>
        </Space>
      ),
    },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Manage Licenses</h1>
      {status === 'loading' ? (
        <p>Loading...</p>
      ) : (
        <>
          {error && <Alert message={`Error: ${error}`} type="error" style={{ marginBottom: '20px' }} />}
          <Button type="primary" onClick={() => setIsFormOpen(true)} style={{ marginBottom: '20px' }}>
            Generate License
          </Button>
          <Table
            columns={columns}
            dataSource={licenses}
            rowKey="moduleLicenceID"
            loading={status === 'loading'}
          />
          <LicenseForm open={isFormOpen} onClose={() => setIsFormOpen(false)} />
        </>
      )}
    </div>
  );
};

export default LicensePage;
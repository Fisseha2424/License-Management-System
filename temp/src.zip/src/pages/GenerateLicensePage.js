import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getLicenses, exportLicense } from "../slices/licenseSlice";
import { getSubscriptions } from "../slices/companyProductSubscriptionSlice";
import { getCompanies } from "../slices/companySlice";
import { getProducts } from "../slices/productSlice";
import LicenseForm from "../components/GenerateLicenseForm";
import { Button, Alert, Table, Space } from "antd";

const GenerateLicensePage = () => {
  const dispatch = useDispatch();
  const { licenses, status, error } = useSelector(
    (state) => state.license || {}
  );
  const { subscriptions = [] } = useSelector(
    (state) => state.subscription || {}
  );

  const { companies } = useSelector((state) => state.company || {});
  const { products } = useSelector((state) => state.product || {});
  const [isFormOpen, setIsFormOpen] = useState(false);

  useEffect(() => {
    dispatch(getLicenses());
    dispatch(getSubscriptions());
    dispatch(getCompanies());
    dispatch(getProducts());
  }, [dispatch]);

  const getCompanyName = (companyID) => {
    const company = companies.find((c) => c.companyID === companyID);
    return company ? company.companyName : "Unknown";
  };

  const getProductName = (productID) => {
    const product = products.find((p) => p.productID === productID);
    return product ? product.productName : "Unknown";
  };

  const getSubscriptionDetails = (companyProductID) => {
    const subscription = subscriptions.find(
      (s) => s.companyProductID === companyProductID
    );
    if (subscription) {
      return `${getCompanyName(subscription.companyID)} - ${getProductName(
        subscription.productID
      )}`;
    }
    return "Unknown";
  };

  const handleDownload = (companyProductID) => {
    dispatch(exportLicense(companyProductID)).then((action) => {
      if (action.payload) {
        const jsonData = JSON.stringify(action.payload, null, 2);
        const blob = new Blob([jsonData], { type: "application/json" });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `license_${companyProductID}.json`;
        a.click();
        window.URL.revokeObjectURL(url);
      }
    });
  };

  const columns = [
    {
      title: "Subscription",
      dataIndex: "companyProductID",
      key: "companyProductID",
      render: (id) => getSubscriptionDetails(id),
    },
    {
      title: "Expiry Date",
      dataIndex: "expiryDate",
      key: "expiryDate",
      render: (date) => new Date(date).toLocaleDateString(),
    },
    { title: "No. of Devices", dataIndex: "noOfDevice", key: "noOfDevice" },
    { title: "No. of Users", dataIndex: "noOfUser", key: "noOfUser" },
    { title: "License Type", dataIndex: "licenseType", key: "licenseType" },
    {
      title: "Actions",
      key: "actions",
      render: (_, record) => (
        <Space>
          <Button onClick={() => handleDownload(record.companyProductID)}>
            Download
          </Button>
        </Space>
      ),
    },
  ];

  return (
    <div>
      <h1 className="text-2xl font-bold mb-4">Generate License</h1>
      {status === "loading" ? (
        <p>Loading...</p>
      ) : (
        <>
          {error && (
            <Alert
              message={`Error: ${error}`}
              type="error"
              style={{ marginBottom: "20px" }}
            />
          )}
          <Button
            type="primary"
            onClick={() => setIsFormOpen(true)}
            style={{ marginBottom: "20px" }}
          >
            Generate New License
          </Button>
          <Table
            columns={columns}
            dataSource={licenses}
            rowKey="companyProductID"
            loading={status === "loading"}
          />
          <LicenseForm open={isFormOpen} onClose={() => setIsFormOpen(false)} />
        </>
      )}
    </div>
  );
};

export default GenerateLicensePage;

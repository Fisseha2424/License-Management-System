import React from 'react';
import CardView from '../components/CardView';
import PaymentPage from '../pages/PaymentPage'; // Main payment management
import PaymentHistoryPage from '../pages/PaymentHistoryPage'; // Placeholder, create if needed
import PaymentReportPage from '../pages/PaymentReportPage'; // Placeholder, create if needed

const PaymentManagementDashboard = () => {
  return (
    <div className="dashboard-container">
      <CardView><PaymentPage /></CardView>
      <CardView><PaymentHistoryPage /></CardView> {/* Add actual component if available */}
      <CardView><PaymentReportPage /></CardView> {/* Add actual component if available */}
    </div>
  );
};

export default PaymentManagementDashboard;
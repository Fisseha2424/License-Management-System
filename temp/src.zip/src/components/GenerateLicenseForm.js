import React, { useEffect } from "react";
import { Form, Input, Button, Modal, Select, InputNumber, Alert } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { generateLicense } from "../slices/licenseSlice";
import { getSubscriptions } from "../slices/companyProductSubscriptionSlice";

const { Option } = Select;

const LicenseForm = ({ open, onClose }) => {
  const [form] = Form.useForm();
  const dispatch = useDispatch();
  const { error: licenseError } = useSelector((state) => state.license || {});
  const { subscriptions = [] } = useSelector(
    (state) => state.subscription || {}
  );
  // const { subscriptions = [] } = useSelector(
  //   (state) => state.companyProductSubscription || {}
  // ); // Corrected selector
  const { companies } = useSelector((state) => state.company || {});
  const { products } = useSelector((state) => state.product || {});

  useEffect(() => {
    dispatch(getSubscriptions());
    form.resetFields();
  }, [open, form, dispatch]);

  const onFinish = (values) => {
    console.log("Form values:", JSON.stringify(values, null, 2));
    dispatch(
      generateLicense({
        ...values,
        expiryDate: new Date(values.expiryDate).toISOString(),
      })
    );
    form.resetFields();
    onClose();
  };

  const getCompanyName = (companyID) => {
    const company = companies.find((c) => c.companyID === companyID);
    return company ? company.companyName : "Unknown";
  };

  const getProductName = (productID) => {
    const product = products.find((p) => p.productID === productID);
    return product ? product.productName : "Unknown";
  };

  return (
    <Modal
      title="Generate License"
      open={open}
      onCancel={onClose}
      footer={null}
    >
      {licenseError && (
        <Alert
          message={`Error: ${licenseError}`}
          type="error"
          showIcon
          style={{ marginBottom: "16px" }}
        />
      )}
      <Form form={form} onFinish={onFinish} layout="vertical">
        <Form.Item
          name="companyProductID"
          label="Company-Product Subscription"
          rules={[{ required: true, message: "Please select a subscription" }]}
        >
          <Select placeholder="Select subscription">
            {subscriptions.map((subscription) => (
              <Option
                key={subscription.companyProductID}
                value={subscription.companyProductID}
              >
                {`${getCompanyName(subscription.companyID)} - ${getProductName(
                  subscription.productID
                )}`}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          name="expiryDate"
          label="Expiry Date"
          rules={[{ required: true, message: "Please select expiry date" }]}
        >
          <Input type="date" />
        </Form.Item>
        <Form.Item
          name="noOfDevice"
          label="Number of Devices"
          rules={[
            { required: true, message: "Please enter number of devices" },
          ]}
        >
          <InputNumber
            min={0}
            placeholder="Enter number (0 for unlimited)"
            style={{ width: "100%" }}
          />
        </Form.Item>
        <Form.Item
          name="noOfUser"
          label="Number of Users"
          rules={[{ required: true, message: "Please enter number of users" }]}
        >
          <InputNumber
            min={0}
            placeholder="Enter number (0 for unlimited)"
            style={{ width: "100%" }}
          />
        </Form.Item>
        <Form.Item
          name="licenseType"
          label="License Type"
          rules={[{ required: true, message: "Please select license type" }]}
        >
          <Select placeholder="Select license type">
            <Option value={1}>Time-Limited Licenses</Option>
            <Option value={2}>Device-Limited Licenses</Option>
            <Option value={3}>Floating Licenses</Option>
          </Select>
        </Form.Item>
        <Form.Item>
          <div className="flex justify-end gap-2">
            <Button onClick={onClose}>Cancel</Button>
            <Button type="primary" htmlType="submit">
              Generate
            </Button>
          </div>
        </Form.Item>
      </Form>
    </Modal>
  );
};

export default LicenseForm;
